import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'

class Footer extends React.Component {
  render() {
    return (
      <div class="jumbotron text-center">
        <p>Footer</p>
      </div>
    )
  }
}
export default Footer

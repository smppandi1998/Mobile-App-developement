import React, { useState, useEffect } from 'react'
import { View, StyleSheet, Text, Alert, Picker } from 'react-native'
import TextInput from '../components/TextInput'
import { TouchableOpacity } from 'react-native-gesture-handler'
import UserTable from '../components/UserTable'
import Button from '../components/Button'
import { Dialog, Portal } from 'react-native-paper'
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as moment from 'moment';
const Configuredevice = ({ navigation }) => {
  let [site, setsite] = useState([]);
  let [pile, setpile] = useState([]);
  let [hwid, sethwid] = useState([]);
  let [servername, setServername] = useState({ value: '' })
  let [databasename, setdatabasename] = useState('')
  let [pilename, setpilename] = useState('')
  let [measurementname, setmeasurementname] = useState('')
  let [locationname, setlocationname] = useState('')
  const [isDialogVisible, setIsDialogVisible] = useState(false)
  const [pileDialogVisible, setpileDialogVisible] = useState(false)
  const [locationDialogVisible, setlocationDialogVisible] = useState(false)
  const [ClientVisible, setIsclientVisible] = React.useState(false)
  const [sitebuttonVisible, setsitebuttonVisible] =useState(true)
  const [datetextVisible, setdatetextVisible] =useState(false)
  const [piletextVisible, setpiletextVisible] =useState(false)
  const [pilebuttonVisible, setpilebuttonVisible] =useState(true)
  const [locationbuttonVisible, setlocationbuttonVisible] =useState(true)
  const [data, setData] = useState([])
  const [selectedValue, setselectedValue] = useState('')
  const [siteValue, setsiteValue] = useState('')
  const [pileValue, setpileValue] = useState('')
  const [locationValue, setlocationValue] = useState('')
  const [deviceValue, setdeviceValue] = useState('')
  const [Api, setApi] = useState('');
  const [uname, setuname] = useState('');
  const [location, setlocation] = useState([]);
  let [device, setdevice] = useState([]);
  const [siteservername,setsiteservername] = useState({});
  const [dateValue,setdateValue] = useState('');
  const [piledbname,setpiledbname] = useState({});
  const [pilemeasname,setpilemeasname] = useState({});
  const clients = [];
  const sites = [];
  const piles = [];
  const locations = [];
  const devices = [];
  const hwids = [];
 
  const getApitoken = async () => {
    try {
        const token = await AsyncStorage.getItem('token');
        const uname = await AsyncStorage.getItem('uname');
        if(token !== null && uname !== null) {
        setApi(token);
        setuname(uname.replace(/['"]+/g, ''));
        fetchClientlist(token);
        }
    } catch(e) {
      console.log(e);
    }
    }
  
     useEffect(() => {
      getApitoken()
    }, [])
    const Addsite =() =>
    {

    }
    const NavigatClientScreen = () => {
      navigation.reset({
        index: 0,
        routes: [{ name: 'ClientScreen' }],
      })
    }
    const NavigateConfigurefield= () => {
     
      navigation.reset({
        index: 0,
        routes: [{ name: 'Configurefield' }],
      })
    }
  
    const NavigateConfiguredevice= () => {
      
      navigation.reset({
        index: 0,
        routes: [{ name: 'Configuredevice' }],
      })
    }
    
    const NavigatUserScreen = () => {
      navigation.reset({
        index: 0,
        routes: [{ name: 'Dashboard' }],
      })
    }
  
    const NavigatDeviceScreen = () => {
      navigation.reset({
        index: 0,
        routes: [{ name: 'RegisterDevice' }],
      })
    }
    const fetchClientlist = (token) => {
      fetch('https://staging-analytics.weradiate.com/apidbm/client', {
        method: 'GET',
        headers: {
          Accept: 'application/json',
          Authorization: 'Bearer ' + token.replace(/['"]+/g, '') + '',
        },
      })
        .then(response => response.json())
        .then(responseJson => {
          
          clients.push('Select the Clients')
  
          for (var i = 0; i < responseJson.length; i++) {
            const json = responseJson[i].cname
  
            clients.push(json)
          }
         
          setData(clients)
          
        })
        .catch(error => {
          console.error(error)
        })
    }
    
    const fetchSitelist = (itemValue) => {
      var url ='https://staging-analytics.weradiate.com/apidbm/listsite' ;
      
      fetch(url, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
          Accept: 'application/json',
          Authorization: 'Bearer ' + Api.replace(/['"]+/g, '') + '',
        },
        body: JSON.stringify({
          client:itemValue
          }),
      })
        .then(response => response.json())
        .then(responseJson => {
          alert(JSON.stringify(responseJson));
          sites.push('Select the sites')
  
          for (var i = 0; i < responseJson.length; i++) {
            const json = responseJson[i].site
          
  
            sites.push(json)
          }
        
          setsite(sites)
          
        
          
        })
        .catch(error => {
          console.error(error)
        })
    }
    const AddDevice = () => {
      setIsDialogVisible(false);
      var url ='https://staging-analytics.weradiate.com/apidbm/device' ;
      const postMethod = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
          Accept: 'application/json',
          Authorization: 'Bearer ' + Api.replace(/['"]+/g, '') + '',
        },
        body: JSON.stringify({
          client:selectedValue,
          site:siteValue,
          pile:pileValue,
          id:deviceValue,
          location:locationValue,
          datetime:dateValue
          }),
      }
      alert(JSON.stringify(postMethod));
      fetch(url, postMethod )
        .then(response => response.json())
        .then(responseJson => {
          alert(JSON.stringify(responseJson));
       })
        .catch(error => {
          console.error(error)
        })
    }
  
    const fetchPilelist = (itemValue) => {
      const url='https://staging-analytics.weradiate.com/apidbm/listpile';
      const postMethod = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
          Accept: 'application/json',
          Authorization: 'Bearer ' + Api.replace(/['"]+/g, '') + '',
        },
        body: JSON.stringify({
          client:selectedValue,
          site:itemValue
          }),
      }
      
      fetch(url,postMethod )
        .then(response => response.json())
        .then(responseJson => {
          
          piles.push('Select the Piles')
  
          for (var i = 0; i < responseJson.length; i++) {
            const json = responseJson[i].pile
            piledbname[""+responseJson[i].pile+""]=responseJson[i].dbname;
            pilemeasname[""+responseJson[i].pile+""]=responseJson[i].measname;
            piles.push(json)
          }
          alert(JSON.stringify(piles))
          setpile(piles)
          
        })
        .catch(error => {
          console.error(error)
        })
    }
    const fetchLocationlist = (itemValue) => {
      const url='https://staging-analytics.weradiate.com/apidbm/listlocation';
      const postMethod = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
          Accept: 'application/json',
          Authorization: 'Bearer ' + Api.replace(/['"]+/g, '') + '',
        },
        body: JSON.stringify({
          client:selectedValue,
          site:siteValue,
          pile:itemValue
          }),
      }
      alert(JSON.stringify(postMethod));
      fetch(url,postMethod )
        .then(response => response.json())
        .then(responseJson => {
          
          locations.push('Select the location')
          alert(JSON.stringify(responseJson));
          for (var i = 0; i < responseJson.length; i++) {
            const json = responseJson[i].lname
            
            locations.push(json)
          }
          alert(JSON.stringify(locations));
          setlocation(locations)
          
        })
        .catch(error => {
          console.error(error)
        })
    }

    const fetchDevicelist = (selectedValue) => {
      
      var url =
      'https://staging-analytics.weradiate.com/apidbm/listmdev/' +
      '' +
      selectedValue +
      ''
    const Getmethod = {
      method: 'GET',
      headers: {
        'Content-type': 'application/json',
        Accept: 'application/json',
        Authorization: 'Bearer ' + Api.replace(/['"]+/g, '') + '',
      }
      
    }
    
    fetch(url, Getmethod)
      .then(response => response.json())
      .then(responseJson => {
        let hwids1=responseJson["hwids"];
      
        devices.push("Select the devices");
        for(let i=0;i<hwids1.length;i++)
        {
          const activehwid=hwids1[i];
          hwids.push(activehwid);
          // alert(JSON.stringify(activehwid));
          devices.push(activehwid["hwid"]);
          // hwids[""+activehwid["hwid"]+""]=activehwid["date"]
         // hwids.push(hwids1[i]);
        }
       
       setdevice(devices);
       sethwid(hwids);
        
        
      })
      .catch(error => {
        console.error(error)
      })
    }
  
  
    const cliendropdownEnabled = (itemValue) => {
        
      setselectedValue(itemValue);
      // setsitebuttonVisible(false);
      fetchSitelist(itemValue);
      
  
    }
    const sitedropdownEnabled = (itemValue) => {
        
      setsiteValue(itemValue);
     
      // setpilebuttonVisible(false);
      fetchPilelist(itemValue);
    
  
    }
    const piledropdownEnabled = (itemValue) => {
        
      setpileValue(itemValue);
      // setpilebuttonVisible(false);
      // setlocationbuttonVisible(false);
      fetchLocationlist(itemValue);
     
  
    }
    const locationdropdownEnabled = (itemValue) => {
     
      setlocationValue(itemValue);
      // setpilebuttonVisible(false);
      // setlocationbuttonVisible(false);
      fetchDevicelist(selectedValue);
     
  
    }
    const decicedropdownEnabled = (itemValue) => {
     
    setdeviceValue(itemValue);
    
    for(let i=0;i<hwid.length;i++)
    {
      
      const date1=hwid[i]
       if(date1["hwid"]==itemValue)
       {
      
      const datetime=date1["date"];
      //datetime=datetime.toString();
      const date = moment(datetime).format('MM/DD/YYYY');
      const time = moment(datetime).format('HH:mm:ss');
      
      const datestringvalue=date+","+time;
      // alert(JSON.stringify(datestringvalue));
      setdateValue(datestringvalue);
      
      }
    }
    setdatetextVisible(true);
  }

  return(
    <View>
    <View style={styles.container}>
        <TouchableOpacity>
          <Text
            onPress={() => setIsclientVisible(true)}
            onPress={NavigatUserScreen}
            style={styles.touchopacity}
          >
            User
          </Text>
        </TouchableOpacity>

        <TouchableOpacity>
          <Text
            onDismiss={() => setIsclientVisible(false)}
            visible={ClientVisible}
            onPress={NavigatClientScreen}
            style={styles.touchopacity}
          >
            Client
          </Text>
        </TouchableOpacity>

        <TouchableOpacity>
          <Text onPress={NavigateConfigurefield} style={styles.touchopacity}>Configure Field</Text>
        </TouchableOpacity>
        <TouchableOpacity>
          <Text onPress={NavigatDeviceScreen} style={styles.touchopacity}>
            Register Device
          </Text>
        </TouchableOpacity>
        <TouchableOpacity>
          <Text onPress={NavigateConfiguredevice} style={styles.touchopacity}>
            Configure Device
          </Text>
        </TouchableOpacity>

        <Picker
          style={styles.picker}
          selectedValue={selectedValue}
          onValueChange={selectedValue => Logutmodule({ selectedValue })}
        >
          <Picker.Item label={uname} value={uname} />
          <Picker.Item label="Logout" value="Logout" />
          <Picker.Item label="User Mangement" value="User" />
        </Picker>
      </View>
   <View>
   <Button mode="contained" style={styles.button} onPress={() =>setIsDialogVisible(true)}>New Device</Button>
   <Button mode="contained" style={styles.button} onPress={() =>setIsDialogVisible(true)}>Remove Device</Button>
   <Button mode="contained" style={styles.button} onPress={() =>setIsDialogVisible(true)}>Replace Device</Button>
   <Button mode="contained" style={styles.button} onPress={() =>setIsDialogVisible(true)}>Delete Device</Button>
            {/* <Button title="New Device"  style={{}} onPress={() =>setIsDialogVisible(true)} />  
            <Button title="Remove Device"   style={styles.button} onPress={() =>setIsDialogVisible(true)} />  
            <Button title="Replace Device" style={styles.button} color="green"   onPress={() =>setIsDialogVisible(true)} /> 
            <Button title="Delete Device"  style={styles.button} color="red"   onPress={() =>setIsDialogVisible(true)} />  */}
     <Portal>
     <Dialog
       style={{
         width: '40%',
         marginLeft: 'auto',
         marginRight: 'auto',
       }}
       visible={isDialogVisible}
       onDismiss={() => setIsDialogVisible(false)}
     >
       <Dialog.Title
         style={{
           marginLeft: 'auto',
           marginRight: 'auto',
         }}
       >
         Add Device Information
       </Dialog.Title>
       <Dialog.Content
         style={{
           marginLeft: 'auto',
           marginRight: 'auto',
         }}
       >
         <Picker
              selectedValue={selectedValue}
              style={{
                width: '100%',

                marginVertical: 12,
              }}
              onValueChange={itemValue => cliendropdownEnabled(itemValue)}
            >
              {data.map((value, key) => (
                <Picker.Item label={value} value={value} key={key} />
              ))}
            </Picker>

            <Picker
              siteValue={siteValue}
              style={{
                width: '100%',

                marginVertical: 12,
              }}
              onValueChange={itemValue => sitedropdownEnabled(itemValue)}
            >
              {site.map((value, key) => (
                <Picker.Item label={value} value={value} key={key} />
              ))}
            </Picker>
            <Picker
              pileValue={pileValue}
              style={{
                width: '100%',

                marginVertical: 12,
              }}
              onValueChange={itemValue => piledropdownEnabled(itemValue)}
            >
              {pile.map((value, key) => (
                <Picker.Item label={value} value={value} key={key} />
              ))}
            </Picker>
            <Picker
              locationValue={locationValue}
              style={{
                width: '100%',

                marginVertical: 12,
              }}
              onValueChange={itemValue => locationdropdownEnabled(itemValue)}
            >
 

              {location.map((value, key) => (
                <Picker.Item label={value} value={value} key={key} />
              ))}
            </Picker> 
            <Picker
             //  enabled={false}
               deviceValue={deviceValue}
              style={{
                width: '100%',

                marginVertical: 12,
              }}
              onValueChange={itemValue => decicedropdownEnabled(itemValue)}
            >
 

              {device.map((value, key) => (
                <Picker.Item label={value} value={value} key={key} />
              ))}
            </Picker> 
           
             {/* <TextInput
              label="Enter Site name"
              returnKeyType="next"
              defaultValue={dateValue}
              disabled={datetextVisible}
              autoCapitalize="none"
              autoCompleteType="Text"
              textContentType="Text"
              keyboardType="Text"
            /> */}
         
        
       </Dialog.Content>
       <Dialog.Actions>
        
       
        <Button mode="contained" style={styles.button} onPress={AddDevice}>Submit</Button>

         
           <Button mode="contained" style={styles.button} onPress={() => setIsDialogVisible(false)}>Cancel</Button>
       </Dialog.Actions>
     </Dialog>
   </Portal>
    </View>   
    </View> 
  )}
  const styles = StyleSheet.create({
    container: {
      width: '100%',
      height: 45,
      backgroundColor: '#606070',
      flexDirection: 'row',
      display: 'flex', 
      justifyContent: 'space-between'
    },
    button: {
      width:'15%',
      
  border: 'none',
  color: 'white',
  padding: '15px 32px',
  textAlign: 'center',
  textDecoration: 'none',
  display: 'inline-block',
  fontSize: '3vw',
  marginLeft: 'auto',
      marginRight: 'auto',
    },
    row: {
      flexDirection: 'row',
    },
    dilog: {
      width: '40%',
      marginLeft: 'auto',
      marginRight: 'auto',
    },
    dilog_content: {
      marginLeft: 'auto',
      marginRight: 'auto',
    },
    touchopacity: {
      color: 'white',
      fontSize: 20,
      padding: 10,
    },
    picker: {
      width: 100,
      backgroundColor: '#FFF0E0',
      borderColor: 'black',
      borderWidth: 1,
    },
    form:{
      width: '500px',
      padding: '10px',
      border: '5px solid gray',
      marginLeft: 'auto',
      marginRight: 'auto',
    }
  })
export default Configuredevice
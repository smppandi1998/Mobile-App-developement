# Mobile-App-developement
Setup:
	      *First install expo app in your mobile phone
		  *Install react_expo on your pc
		  * install yarn in your pc
1)Calculator app
    * Download the clone project
    *Open the code in visual studio code editor
    *open terminal window then run npm install command	
	*Then run npm start command in terminal
	*Scan the Qr code through mobile 
	
	
2) Login page

    * Download the clone project
    *Open the code in visual studio code editor
    *open terminal window then run npm install command	
	*Then run npm start command in terminal
	*Scan the Qr code through mobile 
	
	
		  		  
# Run- time error'-2146232576 (80131700)': Automation error  Solution:
## Steps:
1. Click on start button or press windows button on keyboard.
2. Type feature- it will shows option "Turn windows Features on or off" Click on that
<img src="https://github.com/smppandi1998/Mobile-App-developement/blob/main/Calculator/util/first.png" ><br />

3. Select the square button .NET Framework 3.5 (includes .NET 3.0 and 2.0)
    <img src="https://github.com/smppandi1998/Mobile-App-developement/blob/main/Calculator/util/second.png" ><br />
4. After select it's look like
<img src="https://github.com/smppandi1998/Mobile-App-developement/blob/main/Calculator/util/third.png"><br />

5. Press ok button
<img src="https://github.com/smppandi1998/Mobile-App-developement/blob/main/Calculator/util/third.png"><br />

6. Wait for windows configure (Note- your pc require internet connection,as windows will download some files )after windows configured this,below some more stets will be required
7. Open google type <b>"dotnetfx35.exe"</b> and download from microsoft url then install this
<img src="https://github.com/smppandi1998/Mobile-App-developement/blob/main/Calculator/util/four.png" ><br />

8. After install Reatart your pc




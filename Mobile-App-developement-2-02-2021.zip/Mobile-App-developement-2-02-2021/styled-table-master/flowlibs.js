declare module "polished" {
  declare module.exports: any;
}

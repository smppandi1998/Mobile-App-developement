export function otpValidator(name) {
    if (!name || name.length <= 0) return "OTP can't be empty."
    return ''
  }
  